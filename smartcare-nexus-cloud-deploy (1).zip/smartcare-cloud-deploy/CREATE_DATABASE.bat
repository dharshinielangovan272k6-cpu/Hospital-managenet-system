@echo off
setlocal
title SmartCare Nexus - Create Database

echo Looking for the MySQL command-line client...
set "MYSQL_EXE="
for %%P in (
 "C:\Program Files\MySQL\MySQL Server 8.4\bin\mysql.exe"
 "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
 "C:\Program Files\MySQL\MySQL Server 9.0\bin\mysql.exe"
 "C:\Program Files\MySQL\MySQL Server 9.1\bin\mysql.exe"
) do if exist %%P set "MYSQL_EXE=%%~P"
if not defined MYSQL_EXE (
  for /f "delims=" %%M in ('where mysql.exe 2^>nul') do if not defined MYSQL_EXE set "MYSQL_EXE=%%M"
)
if not defined MYSQL_EXE (
  echo ERROR: mysql.exe was not found.
  echo If MySQL Workbench is installed, open it, connect to your local server, and run:
  echo CREATE DATABASE IF NOT EXISTS smartcare_nexus;
  echo Otherwise find mysql.exe in your MySQL Server installation folder.
  pause
  exit /b 1
)
set "DB_USERNAME=root"
set /p "DB_USERNAME=MySQL username [root]: "
if not defined DB_USERNAME set "DB_USERNAME=root"
echo Enter password when prompted. If your MySQL account has no password, press Enter.
"%MYSQL_EXE%" -u "%DB_USERNAME%" -p -e "CREATE DATABASE IF NOT EXISTS smartcare_nexus CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
if errorlevel 1 (
  echo Database creation failed. Check the MySQL service and credentials.
) else (
  echo Database smartcare_nexus is ready.
)
pause
