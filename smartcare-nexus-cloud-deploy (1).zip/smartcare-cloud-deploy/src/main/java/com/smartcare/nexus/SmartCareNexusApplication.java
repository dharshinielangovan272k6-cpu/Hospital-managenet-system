package com.smartcare.nexus;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SmartCareNexusApplication {
    public static void main(String[] args) { SpringApplication.run(SmartCareNexusApplication.class, args); }
}
