package com.smartcare.nexus.appointment;
import org.springframework.beans.factory.annotation.Value; import org.springframework.mail.SimpleMailMessage; import org.springframework.mail.MailException; import org.springframework.mail.javamail.JavaMailSender; import org.springframework.stereotype.Service; import java.time.format.DateTimeFormatter;
@Service public class AppointmentEmailService {
 private final JavaMailSender sender; private final String username;
 public AppointmentEmailService(JavaMailSender sender,@Value("${spring.mail.username:}") String username){this.sender=sender;this.username=username;}
 public boolean sendConfirmation(Appointment a){
  if(username==null||username.isBlank())return false;
  try{SimpleMailMessage m=new SimpleMailMessage();m.setFrom(username);m.setTo(a.getPatientEmail());m.setSubject("Appointment Confirmed - SmartCare Nexus");
   m.setText("Dear "+a.getPatientName()+",\\n\\nYour appointment is confirmed!\\n\\nBooking ID: "+a.getBookingReference()+"\\nDoctor: "+a.getDoctorName()+"\\nDepartment: "+a.getSpecialty()+"\\nDate: "+a.getAppointmentDate().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"))+"\\nTime: "+a.getAppointmentTime().format(DateTimeFormatter.ofPattern("hh:mm a"))+"\\nStatus: "+a.getStatus()+"\\n\\nPlease arrive 15 minutes before your scheduled time.\\n\\nThank you,\\nSmartCare Nexus");
   sender.send(m);return true;
  }catch(MailException ex){return false;}
 }
}
