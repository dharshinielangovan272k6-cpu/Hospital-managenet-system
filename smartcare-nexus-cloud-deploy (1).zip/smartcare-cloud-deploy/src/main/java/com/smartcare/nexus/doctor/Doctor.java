package com.smartcare.nexus.doctor;
public record Doctor(Long id, String name, String specialty, String department) {}
