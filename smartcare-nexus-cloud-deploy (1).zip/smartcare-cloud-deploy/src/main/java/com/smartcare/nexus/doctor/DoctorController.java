package com.smartcare.nexus.doctor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
@RestController
public class DoctorController {
 @GetMapping("/api/doctors")
 public List<Doctor> doctors() {
  return List.of(new Doctor(1L,"Dr. Priya","General Medicine","Outpatient"),
   new Doctor(2L,"Dr. Arjun","Cardiology","Heart Care"),
   new Doctor(3L,"Dr. Meera","Dermatology","Skin Care"),
   new Doctor(4L,"Dr. Karthik","Orthopaedics","Bone & Joint"));
 }
}
