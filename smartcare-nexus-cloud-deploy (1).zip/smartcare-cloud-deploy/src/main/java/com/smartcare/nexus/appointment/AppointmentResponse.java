package com.smartcare.nexus.appointment;
import java.time.LocalDate; import java.time.LocalTime;
public record AppointmentResponse(Long id,String bookingReference,String patientName,String patientEmail,String doctorName,String specialty,LocalDate appointmentDate,LocalTime appointmentTime,String status,boolean emailSent,String message){
 public static AppointmentResponse from(Appointment a,boolean sent,String msg){return new AppointmentResponse(a.getId(),a.getBookingReference(),a.getPatientName(),a.getPatientEmail(),a.getDoctorName(),a.getSpecialty(),a.getAppointmentDate(),a.getAppointmentTime(),a.getStatus(),sent,msg);}
}
