package com.smartcare.nexus.appointment;
import com.smartcare.nexus.doctor.Doctor; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional; import java.time.LocalDate; import java.util.List; import java.util.UUID;
@Service public class AppointmentService {
 private final AppointmentRepository repository; private final AppointmentEmailService email;
 public AppointmentService(AppointmentRepository repository,AppointmentEmailService email){this.repository=repository;this.email=email;}
 private Doctor doctorFor(Long id){return switch(id.intValue()){
  case 1->new Doctor(1L,"Dr. Priya","General Medicine","Outpatient"); case 2->new Doctor(2L,"Dr. Arjun","Cardiology","Heart Care"); case 3->new Doctor(3L,"Dr. Meera","Dermatology","Skin Care"); case 4->new Doctor(4L,"Dr. Karthik","Orthopaedics","Bone & Joint"); default->throw new IllegalArgumentException("Please select a valid doctor.");};}
 @Transactional public AppointmentResponse book(AppointmentRequest r){
  if(r.appointmentDate().isBefore(LocalDate.now()))throw new IllegalArgumentException("Appointment date cannot be in the past.");
  Doctor d=doctorFor(r.doctorId());
  if(repository.existsByDoctorIdAndAppointmentDateAndAppointmentTimeAndStatus(r.doctorId(),r.appointmentDate(),r.appointmentTime(),"CONFIRMED"))throw new IllegalArgumentException("This doctor already has a booking at that date and time. Please choose another slot.");
  String ref="SCN-"+UUID.randomUUID().toString().substring(0,8).toUpperCase();
  Appointment a=repository.saveAndFlush(new Appointment(r.patientName().trim(),r.patientEmail().trim(),r.phone().trim(),d.id(),d.name(),d.specialty(),r.appointmentDate(),r.appointmentTime(),r.reason()==null?"":r.reason().trim(),ref));
  boolean sent=email.sendConfirmation(a);
  return AppointmentResponse.from(a,sent,sent?"Appointment booked. Confirmation email sent.":"Appointment booked, but email was not sent. Configure SMTP credentials and check server configuration.");
 }
 public List<Appointment> all(){return repository.findAllByOrderByCreatedAtDesc();}
}
