package com.smartcare.nexus.appointment;
import jakarta.validation.Valid; import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/appointments") public class AppointmentController {
 private final AppointmentService service; public AppointmentController(AppointmentService service){this.service=service;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public AppointmentResponse book(@Valid @RequestBody AppointmentRequest r){try{return service.book(r);}catch(IllegalArgumentException ex){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,ex.getMessage());}}
 // Demo-only: protect with staff authentication before deployment.
 @GetMapping public List<Appointment> all(){return service.all();}
}
