package com.smartcare.nexus.appointment;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
@Entity @Table(name="appointments", indexes={@Index(name="idx_appointment_date_time",columnList="appointment_date, appointment_time")})
public class Appointment {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,length=120) private String patientName;
 @Column(nullable=false,length=190) private String patientEmail;
 @Column(nullable=false,length=20) private String phone;
 @Column(nullable=false) private Long doctorId;
 @Column(nullable=false,length=100) private String doctorName;
 @Column(nullable=false,length=100) private String specialty;
 @Column(name="appointment_date",nullable=false) private LocalDate appointmentDate;
 @Column(name="appointment_time",nullable=false) private LocalTime appointmentTime;
 @Column(length=500) private String reason;
 @Column(nullable=false,unique=true,length=40) private String bookingReference;
 @Column(nullable=false,length=20) private String status="CONFIRMED";
 @Column(nullable=false) private LocalDateTime createdAt=LocalDateTime.now();
 protected Appointment(){}
 public Appointment(String patientName,String patientEmail,String phone,Long doctorId,String doctorName,String specialty,LocalDate appointmentDate,LocalTime appointmentTime,String reason,String bookingReference){
  this.patientName=patientName;this.patientEmail=patientEmail;this.phone=phone;this.doctorId=doctorId;this.doctorName=doctorName;this.specialty=specialty;this.appointmentDate=appointmentDate;this.appointmentTime=appointmentTime;this.reason=reason;this.bookingReference=bookingReference;this.status="CONFIRMED";this.createdAt=LocalDateTime.now();
 }
 public Long getId(){return id;} public String getPatientName(){return patientName;} public String getPatientEmail(){return patientEmail;} public String getPhone(){return phone;} public Long getDoctorId(){return doctorId;} public String getDoctorName(){return doctorName;} public String getSpecialty(){return specialty;} public LocalDate getAppointmentDate(){return appointmentDate;} public LocalTime getAppointmentTime(){return appointmentTime;} public String getReason(){return reason;} public String getBookingReference(){return bookingReference;} public String getStatus(){return status;} public LocalDateTime getCreatedAt(){return createdAt;}
}
