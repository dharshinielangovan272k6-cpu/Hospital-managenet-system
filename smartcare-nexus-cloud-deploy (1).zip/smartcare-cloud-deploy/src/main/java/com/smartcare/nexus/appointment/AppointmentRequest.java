package com.smartcare.nexus.appointment;
import jakarta.validation.constraints.*; import java.time.LocalDate; import java.time.LocalTime;
public record AppointmentRequest(@NotBlank @Size(max=120) String patientName,@NotBlank @Email @Size(max=190) String patientEmail,@NotBlank @Pattern(regexp="^[0-9+() -]{7,20}$") String phone,@NotNull @Min(1) @Max(4) Long doctorId,@NotNull @FutureOrPresent LocalDate appointmentDate,@NotNull LocalTime appointmentTime,@Size(max=500) String reason){}
