# SmartCare Nexus — Online deployment notes

This project is configured for a Docker-based Spring Boot deployment (Java 17) on Render and an external MySQL database such as Aiven MySQL Free.

## Important
- Do not upload real patient data or passwords to GitHub.
- This is a student/demo project, not a production-ready hospital system.
- Only the appointment backend is currently implemented as database-backed functionality; other UI modules are demo workflows.
- Free hosting plans may sleep, have usage limits, or change; do not rely on them for production.

## 1. Create a MySQL database
1. Create an Aiven account and create a MySQL Free service if available in your account/region.
2. Wait until the service is running.
3. Open the service's connection details and copy host, port, database name, username, and password. Keep them private.
4. Use the connection details to form a JDBC URL:
   `jdbc:mysql://HOST:PORT/DATABASE?sslMode=REQUIRED`
   Replace HOST, PORT, and DATABASE with Aiven's exact values.

## 2. Upload the source to GitHub
1. Create a new private repository on GitHub (recommended while developing).
2. Extract this ZIP locally.
3. On the repository page choose Add file > Upload files and upload the project files/folders (not the ZIP itself). GitHub browser uploads have a 100-file-at-once limit.
4. Commit the files. Never commit passwords, database credentials, or real patient data.

## 3. Deploy the backend + static frontend to Render
1. Sign in to Render and choose New > Web Service.
2. Connect the GitHub repository.
3. Choose Docker as the runtime/environment so Render uses the included Dockerfile.
4. Select the Free plan if offered.
5. Add environment variables under the service's Environment section:
   - `DB_URL` = `jdbc:mysql://HOST:PORT/DATABASE?sslMode=REQUIRED`
   - `DB_USERNAME` = Aiven's username
   - `DB_PASSWORD` = Aiven's password
6. Deploy and watch the logs until the service is live.
7. Open the Render URL. The static UI is packaged in `src/main/resources/static` and served by Spring Boot.

## Notes
- The Dockerfile builds the app in the cloud; no local Java or Maven installation is needed for deployment.
- `server.port=${PORT:8080}` allows Render to choose the listening port.
- If the build fails, inspect Render deploy logs and check that the project root contains `pom.xml`, `Dockerfile`, and `src/`.
- Email sending is not configured by default. Add `MAIL_USERNAME` and `MAIL_APP_PASSWORD` only if you configure SMTP; never commit these values.
