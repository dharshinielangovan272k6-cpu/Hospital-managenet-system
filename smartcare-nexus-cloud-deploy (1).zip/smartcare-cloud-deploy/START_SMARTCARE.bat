@echo off
setlocal
cd /d "%~dp0"
title SmartCare Nexus - Full Stack Launcher

echo ==============================================
echo       SMARTCARE NEXUS - FULL STACK
 echo ==============================================
echo.
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java was not found on PATH.
  echo Your Java installation should be available from a new terminal.
  pause
  exit /b 1
)

set "MAVEN_BIN=C:\tools\apache-maven-3.10.0\bin"
if exist "%MAVEN_BIN%\mvn.cmd" set "PATH=%PATH%;%MAVEN_BIN%"
where mvn >nul 2>nul
if errorlevel 1 (
  echo ERROR: Maven was not found. Expected at C:\tools\apache-maven-3.10.0\bin\mvn.cmd
  echo Check Maven installation or update MAVEN_BIN near the top of this file.
  pause
  exit /b 1
)

if not exist pom.xml (
  echo ERROR: pom.xml not found. Keep this BAT file beside pom.xml.
  pause
  exit /b 1
)

echo Enter the MySQL username. Default is root.
set "DB_USERNAME=root"
set /p "DB_USERNAME=MySQL username [root]: "
if not defined DB_USERNAME set "DB_USERNAME=root"
set "DB_PASSWORD="
set /p "DB_PASSWORD=MySQL password (input is visible): "
set "DB_URL=jdbc:mysql://localhost:3306/smartcare_nexus"

echo.
echo Starting Spring Boot. Keep this window open.
echo When the log says the application started, open http://localhost:8080
 echo.
call mvn spring-boot:run
if errorlevel 1 (
  echo.
  echo SmartCare Nexus did not start. Read the error above; common causes are MySQL not running,
  echo wrong credentials, or database smartcare_nexus not created.
)
pause
