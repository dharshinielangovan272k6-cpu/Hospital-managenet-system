SMARTCARE NEXUS - FULL-STACK STARTER (Windows)

This package includes the HTML/CSS/JavaScript frontend and Spring Boot Java backend from the provided project.
The existing backend currently persists appointment records through MySQL. The other dashboard modules are demo/localStorage workflows and are not all backed by database tables yet. Do not use real patient data.

REQUIREMENTS
- Java JDK 17+ (you have Java 24 installed; it may work, but Java 17 or 21 LTS is recommended if build compatibility errors occur)
- Apache Maven (launcher checks C:\tools\apache-maven-3.10.0\bin and PATH)
- MySQL Server running on localhost:3306

FIRST-TIME SETUP
1. Ensure MySQL Server is installed and its Windows service is Running.
2. Double-click CREATE_DATABASE.bat. It creates database smartcare_nexus.
   If mysql.exe cannot be found, open MySQL Workbench, connect to your local server and run:
       CREATE DATABASE IF NOT EXISTS smartcare_nexus;
3. Double-click START_SMARTCARE.bat and enter your MySQL username/password.
4. Wait for the Spring Boot startup success message.
5. Open http://localhost:8080 in Chrome.
6. Keep the launcher terminal open while using the app. Close it to stop the server.

API endpoints currently included:
- GET /api/doctors
- GET /api/appointments
- POST /api/appointments

Important: This is a student demo, not a production-ready hospital system. Other modules are not yet fully API/database-backed. Authentication, role-based authorization, audit logging, privacy controls, backups, and security hardening are required before real-world use.
