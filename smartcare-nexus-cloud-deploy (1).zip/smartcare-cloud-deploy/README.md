# SmartCare Nexus — Complete Hospital Management Suite (Student Project Starter)

## Included modules
Dashboard, Patient Management, Doctor Management, Appointments, Prescriptions, Medicines/Pharmacy, Laboratory, X-Ray/Imaging, Beds & Admissions, Billing, Insurance, Reports, and AI Assistant interface.

## Stack
HTML, CSS, JavaScript; Java 17+ / Spring Boot 3; Spring Data JPA / Hibernate; MySQL 8; Spring Mail / Gmail SMTP.

## Important implementation status
- The responsive multi-module interface and sample records are included.
- The browser demo stores module actions in localStorage so you can click through the modules without waiting for backend endpoints.
- Appointment booking is connected to the Java API and MySQL, and attempts to send a confirmation email if SMTP is configured.
- The other modules are currently UI/demo workflows, not yet backed by database tables or real hospital integrations. The AI assistant is a demo interface, not a connected LLM.
- This is not a production-ready hospital system. Do not enter real patient information or deploy publicly before implementing authentication, authorization, audit logging, secure API endpoints, backups, HTTPS, privacy safeguards and medical workflow validation.

## Run
1. Install Java 17+ and Maven.
2. Create database:
   ```sql
   CREATE DATABASE smartcare_nexus;
   ```
3. Configure environment variables:
   - `DB_URL=jdbc:mysql://localhost:3306/smartcare_nexus`
   - `DB_USERNAME=your_mysql_username`
   - `DB_PASSWORD=your_mysql_password`
   - `MAIL_USERNAME=your_gmail_address`
   - `MAIL_APP_PASSWORD=your_google_app_password`
4. In this project folder:
   ```bash
   mvn spring-boot:run
   ```
5. Open http://localhost:8080

PowerShell:
```powershell
$env:DB_URL="jdbc:mysql://localhost:3306/smartcare_nexus"
$env:DB_USERNAME="root"
$env:DB_PASSWORD="your_mysql_password"
$env:MAIL_USERNAME="your_gmail_address"
$env:MAIL_APP_PASSWORD="your_google_app_password"
mvn spring-boot:run
```

Use a Google App Password, not your regular Gmail password. Keep secrets out of source control.

## API available in this starter
- `GET /api/doctors`
- `GET /api/appointments`
- `POST /api/appointments`

Appointment list is a demo endpoint and is unprotected; secure it before deployment. Doctor records are currently demo data. Appointment collision checking is a basic demo check; a production system needs transactional slot locking/unique constraints and proper clinic schedules.

## Next engineering steps
1. Add Spring Security login with PATIENT, DOCTOR, NURSE, LAB_STAFF, PHARMACIST, BILLING, ADMIN roles.
2. Create JPA entities and migrations for patients, prescriptions, medicine inventory, lab orders/results, imaging, beds/admissions, invoices/payments, insurance claims and discharge workflow.
3. Add validated, role-protected service/controller APIs and object-level access checks.
4. Replace localStorage demo workflows with API calls.
5. Connect the AI assistant to an LLM using allow-listed server-side tools; never expose an API key in browser code or permit unrestricted database access.
6. Add tests, audit trail, email retry/outbox, monitoring and deployment configuration.
